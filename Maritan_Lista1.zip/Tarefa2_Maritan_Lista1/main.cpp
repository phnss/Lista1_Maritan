#include <iostream>

#include "Pessoa.h"
using namespace std;

int main(){

    Pessoa p1 = Pessoa("Pedro");
    Pessoa p2 = Pessoa("Pessoa", 19, "83996284474");

    p1.setIdade(22);
    p1.setTelefone("96981030474");

    cout << "Nome: " << p1.getNome() << "/Idade: " << p1.getIdade() << "/Telefone: " << p1.getTelefone() << endl;
    cout << "Nome: " << p2.getNome() << "/Idade: " << p2.getIdade() << "/Telefone: " << p2.getTelefone() << endl;

    return 0;
}
