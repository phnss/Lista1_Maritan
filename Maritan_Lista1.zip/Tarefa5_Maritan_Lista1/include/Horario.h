#ifndef HORARIO_H
#define HORARIO_H


class Horario
{
    public:
        Horario();
        Horario(int hora, int minuto, int segundos);

        void setHorario(int hora, int minuto, int segundos);
        void avancarHorario();

        void setHora(int h);
        void setMinuto(int m);
        void setSegundos(int s);

        int getHora();
        int getMinuto();
        int getSegundos();

    private:
        int hora, minuto, segundos;
};

#endif // HORARIO_H
