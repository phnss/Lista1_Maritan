#include <iostream>
#include <locale>

#include "Horario.h"

using namespace std;

int main(){
    setlocale(LC_ALL, "Portuguese");

    Horario h1 = Horario();
    Horario h2 = Horario(24, 59, 59);

    h1.setHorario(12, 0, 59);

    cout << "Hora 1 = " << h1.getHora() << ":" << h1.getMinuto() << ":" << h1.getSegundos() << endl;
    h1.avancarHorario();
    cout << h1.getHora() << ":" << h1.getMinuto() << ":" << h1.getSegundos() << endl;


    cout << "Hora 2 = " <<  h2.getHora() << ":" << h2.getMinuto() << ":" << h2.getSegundos() << endl;
    h2.avancarHorario();
    cout << h2.getHora() << ":" << h2.getMinuto() << ":" << h2.getSegundos() << endl;

    return 0;
}
