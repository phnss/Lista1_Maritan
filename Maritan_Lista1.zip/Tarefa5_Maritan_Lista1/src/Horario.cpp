#include "Horario.h"

Horario::Horario(){
    hora = 0;
    minuto = 0;
    segundos = 0;
}

Horario::Horario(int hora, int minuto, int segundos){
    this->hora = hora;
    this->minuto = minuto;
    this->segundos = segundos;

    if(this->segundos >= 60 || this->minuto >= 60 || this->hora >= 24){
        this->hora = 0;
        this->minuto = 0;
        this->segundos = 0;
    }
}

void Horario::setHorario(int hora, int minuto, int segundos){
    this->hora = hora;
    this->minuto = minuto;
    this->segundos = segundos;

    if(this->segundos >= 60 || this->minuto >= 60 || this->hora >= 24){
        hora = 0;
        minuto = 0;
        segundos = 0;
    }
}

void Horario::avancarHorario(){
    segundos++;

    if(segundos == 60){
        segundos = 0;
        minuto++;
    }

    if(minuto == 60){
        minuto = 0;
        hora++;
    }

    if(hora > 23){
        hora = 0;
        minuto = 0;
        segundos = 0;
    }
}

void Horario::setHora(int h){
    hora = h;
}

void Horario::setMinuto(int m){
    minuto = m;
}

void Horario::setSegundos(int s){
    segundos = s;
}

int Horario::getHora(){
    return hora;
}

int Horario::getMinuto(){
    return minuto;
}

int Horario::getSegundos(){
    return segundos;
}
