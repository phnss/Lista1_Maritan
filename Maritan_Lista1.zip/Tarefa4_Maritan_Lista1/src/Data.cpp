#include <iostream>
#include <stdlib.h>

#include "Data.h"

using namespace std;

Data::Data(){
    dia = 01;
    mes = 01;
    ano = 0001;
}

Data::Data(int dia, int mes, int ano){
    this->dia = dia;
    this->mes = mes;
    this->ano = ano;

    if(isBissexto()){
        if((mes == 1 && dia > 31 )|| (mes == 2 && dia > 29)
           || (mes == 3 && dia > 31) || (mes == 4 && dia > 30)
           || (mes == 5 && dia > 31) || (mes == 6 && dia > 30)
           || (mes == 7 && dia > 31) || (mes == 8 && dia > 31)
           || (mes == 9 && dia > 30) || (mes == 10 && dia > 31)
           || (mes == 11 && dia > 30) || (mes == 12 && dia > 31 || dia < 0)
           || (mes > 12 && mes < 0) || ano < 0){

                this->dia = 01;
                this->mes = 01;
                this->ano = 0001;
        }
    }else{
        if((mes == 1 && dia > 31 )|| (mes == 2 && dia > 28)
           || (mes == 3 && dia > 31) || (mes == 4 && dia > 30)
           || (mes == 5 && dia > 31) || (mes == 6 && dia > 30)
           || (mes == 7 && dia > 31) || (mes == 8 && dia > 31)
           || (mes == 9 && dia > 30) || (mes == 10 && dia > 31)
           || (mes == 11 && dia > 30) || (mes == 12 && dia > 31 || dia < 0)
           || (mes > 12 && mes < 0) || ano < 0){

            this->dia = 01;
            this->mes = 01;
            this->ano = 0001;
        }
    }
}

bool Data::compararData(Data d){
    if(ano == d.getAno()){
        if(mes == d.getMes()){
            if(dia == d.getDia()){
                return 1;
            }
        }
    }
}

bool Data::isBissexto(){
    if(ano % 400 == 0 || (ano % 4 == 0 && ano % 100 != 0)){
        return true;
    }else{
        return false;
    }
}

std::string Data::getMesExtenso(){
    if(mes == 1){
        return "Janeiro";
    }if(mes == 2){
        return "Fevereiro";
    }if(mes == 3){
        return "Mar�o";
    }if(mes == 4){
        return "Abril";
    }if(mes == 5){
        return "Maio";
    }if(mes == 6){
        return "Junho";
    }if(mes == 7){
        return "Julho";
    }if(mes == 8){
        return "Agosto";
    }if(mes == 9){
        return "Setembro";
    }if(mes == 10){
        return "Outubro";
    }if(mes == 11){
        return "Novembro";
    }if(mes == 12){
        return "Dezembro";
    }
}


int Data::getDia(){
    return dia;
}

int Data::getMes(){
    return mes;
}

int Data::getAno(){
    return ano;
}

void Data::setDia(int d){
        dia = d;

    if(isBissexto()){
        if((mes == 1 && dia > 31 )|| (mes == 2 && dia > 29)
           || (mes == 3 && dia > 31) || (mes == 4 && dia > 30)
           || (mes == 5 && dia > 31) || (mes == 6 && dia > 30)
           || (mes == 7 && dia > 31) || (mes == 8 && dia > 31)
           || (mes == 9 && dia > 30) || (mes == 10 && dia > 31)
           || (mes == 11 && dia > 30) || (mes == 12 && dia > 31 || dia < 0)
           || (mes > 12 && mes < 0) || ano < 0){

            this->dia = 01;
        }
    }else{
        if((mes == 1 && dia > 31 )|| (mes == 2 && dia > 28)
           || (mes == 3 && dia > 31) || (mes == 4 && dia > 30)
           || (mes == 5 && dia > 31) || (mes == 6 && dia > 30)
           || (mes == 7 && dia > 31) || (mes == 8 && dia > 31)
           || (mes == 9 && dia > 30) || (mes == 10 && dia > 31)
           || (mes == 11 && dia > 30) || (mes == 12 && dia > 31 || dia < 0)
           || (mes > 12 && mes < 0) || ano < 0){

            this->dia = 01;
        }
    }
}

void Data::setMes(int m){
    mes = m;

    if(mes > 12 || mes < 0){
        this->mes = 01;
    }
}

void Data::setAno(int a){
    ano = a;

    if(ano < 0){
        this->ano = 01;
    }
}
