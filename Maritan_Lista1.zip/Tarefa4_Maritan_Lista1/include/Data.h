#ifndef DATA_H
#define DATA_H

#include <string>

class Data
{
    public:
        Data();
        Data(int dia, int mes, int ano);

        bool compararData(Data d);
        bool isBissexto();
        std::string getMesExtenso();

        int getDia();
        int getMes();
        int getAno();

        void setDia(int d);
        void setMes(int m);
        void setAno(int a);

    private:
        int dia;
        int mes;
        int ano;
};

#endif // DATA_H
