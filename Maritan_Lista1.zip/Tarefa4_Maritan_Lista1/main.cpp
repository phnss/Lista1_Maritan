#include <iostream>
#include <stdlib.h>
#include <locale>

#include "Data.h"
using namespace std;
/*
void Menu1(){

    cout << "\n(1)- Mudar a data corrente" << endl;
    cout << "(2)- Mudar a data auxiliar" << endl;
    cout << "(3)- Comparar as datas" << endl;
    cout << "(4)- Pegar o m�s corrente por extenso" << endl;
    cout << "(5)- Sair" << endl;

    cout << "Op��o: ";
}
*/
int main()
{
    int opcao;

    setlocale(LC_ALL, "Portuguese");

    Data data1 = Data();
    Data data2 = Data(19, 10, 2000);

/*    while(1){
        cout << "----------------/Verificador de Data/----------------" << endl;
        cout << "Data corrente: " << data1.getDia() << "/" << data1.getMes() << "/" << data1.getAno() << endl;
        cout << "Data auxiliar: " << data2.getDia() << "/" << data2.getMes() << "/" << data2.getAno() << endl;

        Menu1();
        cin >> opcao;

        if(opcao == 1){
            system("cls");

            data1.setDia();
            data1.setMes();
            data1.setAno();

            system("cls");

        }else if(opcao == 2){
            system("cls");

            data2.setDia();
            data2.setMes();
            data2.setAno();

            system("cls");

        }else if(opcao == 3){
            system("cls");

            cout << "A compara��o entre a data corrente e a data auxiliar �: ";

            if(data1.compararData(data2)){
                cout << "Verdadeiro" << endl;
                system("pause");

            }else{
                cout << "Falso" << endl;
                system("pause");

            }
        }else if(opcao == 4){
            system("cls");

            cout << data1.getMesExtenso() << endl;

            system("pause");
            system("cls");

        }else if(opcao == 5){
            break;
        }

        system("cls");
    }
                                                        */
    data1.setDia(19);
    data1.setMes(10);
    data1.setAno(2000);

    cout << "Data corrente: " << data1.getDia() << "/" << data1.getMes() << "/" << data1.getAno() << endl;
    cout << "Data auxiliar: " << data2.getDia() << "/" << data2.getMes() << "/" << data2.getAno() << "\n" <<endl;

    cout << "M�s por extenso da data1: " << data1.getMesExtenso() << endl;
    cout << "M�s por extenso da data2: " << data2.getMesExtenso() << endl;

    cout << "\nA compara��o entre a data corrente e a data auxiliar �: ";
        if(data1.compararData(data2)){
            cout << "Verdadeiro" << endl;

        }else{
            cout << "Falso" << endl;
        }

    return 0;
}
