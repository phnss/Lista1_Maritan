#include <iostream>
#include <locale>

#include "Invoice.h"

using namespace std;

int main(){
    setlocale(LC_ALL, "Portuguese");

    Invoice fatura1 = Invoice();
    Invoice fatura2 = Invoice("134", "Carrinho de Brinquedo", 2, 13.5);

    fatura1.setId("111");
    fatura1.setDescricao("Mouse 180bpm");
    fatura1.setQuantidade(2);
    fatura1.setPreco(20);

    cout << "O produto " << fatura1.getId() << ", com a descri��o /" << fatura1.getDescricao() << "/, teve " << fatura1.getQuantidade()
    << " unidades comprados(as), sendo que seu pre�o unit�rio � de " << fatura1.getPreco() << "$. Portanto o total gasto foi de " <<
    fatura1.getInvoiceAmount() << "$." << endl;

    cout << "\nO produto " << fatura2.getId() << ", com a descri��o /" << fatura2.getDescricao() << "/, teve " << fatura2.getQuantidade()
    << " unidades comprados(as), sendo que seu pre�o unit�rio � de " << fatura2.getPreco() << "$. Portanto o total gasto foi de " <<
    fatura2.getInvoiceAmount() << "$." << endl;

    return 0;
}
