#include "Invoice.h"

#include<string>

using namespace std;

Invoice::Invoice(){
    id = "";
    descricao = "";
    quantidade = 0.0;
    preco = 0.0;
}

Invoice::Invoice(std::string i, std::string d, double q, double p){
    id = i;
    descricao = d;
    quantidade = q;
    preco = p;
}

double Invoice::getInvoiceAmount(){
    return quantidade * preco;
}

string Invoice::getId(){
    return id;
}

string Invoice::getDescricao(){
    return descricao;
}

double Invoice::getQuantidade(){
    return quantidade;
}

double Invoice::getPreco(){
    return preco;
}

void Invoice::setId(std::string i){
    id = i;
}

void Invoice::setDescricao(std::string d){
    descricao = d;
}

void Invoice::setQuantidade(double q){
    quantidade = q;

    if(quantidade < 0){
        quantidade = 0.0;
    }
}

void Invoice::setPreco(double p){
    preco = p;

    if(preco < 0){
        preco = 0.0;
    }
}
