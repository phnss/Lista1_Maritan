#ifndef INVOICE_H
#define INVOICE_H

#include<string>

class Invoice
{
    public:
        Invoice();
        Invoice(std::string i, std::string d, double q, double p);

        double getInvoiceAmount();

        std::string getId();
        std::string getDescricao();
        double getQuantidade();
        double getPreco();

        void setId(std::string i);
        void setDescricao(std::string d);
        void setQuantidade(double q);
        void setPreco(double p);

    private:
        std::string id, descricao;
        double quantidade, preco;
};

#endif // INVOICE_H
