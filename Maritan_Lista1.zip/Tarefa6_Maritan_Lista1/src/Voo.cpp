#include "Voo.h"

using namespace std;

Voo::Voo(){
    numeroDoVoo = "";
    horarioDoVoo = Horario();
    dataDoVoo = Data();
}

Voo::Voo(std::string ndv, Horario hdv, Data ddv){
    numeroDoVoo = ndv;
    horarioDoVoo = hdv;
    dataDoVoo = ddv;
}

int Voo::proximoLivre(){
    for(int i=0;i<100;i++){
        if(assentos[i] == 0){
            return i+1;
        }
    }
}

bool Voo::verifica(int cadeira){
    if(assentos[cadeira - 1] == 0){
        return true;
    }
    return false;
}

bool Voo::ocupa(int cadeira){
    if(assentos[cadeira - 1] == 0){
        assentos[cadeira - 1] = 1;
        return true;
    }
    return false;
}

int Voo::vagas(){
    int vagas = 0;

    for(int i = 0;i < 100;i++){
        if(assentos[i] == 0){
            vagas += 1;
        }
    }
    return vagas;
}

std::string Voo::getNumVoo(){
    return numeroDoVoo;
}

Data Voo::getData(){
    return dataDoVoo;
}

Horario Voo::getHorario(){
    return horarioDoVoo;
}
