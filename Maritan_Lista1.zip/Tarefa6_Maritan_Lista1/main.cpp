#include <iostream>

#include "Horario.h"
#include "Data.h"
#include "Voo.h"

using namespace std;

int main(){
    setlocale(LC_ALL, "Portuguese");

    Voo voo1 = Voo("6034", Horario(17, 20, 00), Data(17, 12, 2019));
    Horario horario1 = voo1.getHorario();
    Data data1 = voo1.getData();

    Voo voo2 = Voo("1234", Horario(32, 214, 1234), Data(24, 10, 2019));
    Horario horario2 = voo2.getHorario();
    Data data2 = voo2.getData();

    cout << "O v�o de n�mero " << voo1.getNumVoo() << ", est� marcado para o dia " << data1.getDia() << "/"
    << data1.getMes() << "/" << data1.getAno() << ", e tem previs�o para sair �s " << horario1.getHora() <<
    ":" << horario1.getMinuto() << ":" << horario1.getSegundos() << ". \nEste v�o ainda possui " << voo1.vagas()
    << " assento(s) livres para serem ocupados" << endl;

    cout << "Em rela��o ao v�o " << voo1.getNumVoo() << " , iremos ocupar a cadeira de n�mero 50, para isso confirmaremos"
    " que ela est� vazia : ";
    if(voo1.verifica(50)){
        cout << "DISPON�VEL" << endl;
    }else{
        cout << "N�O DISPON�VEL" << endl;
    }

    voo2.ocupa(40);

    cout << "\n\nO v�o de n�mero " << voo2.getNumVoo() << ", est� marcado para o dia " << data2.getDia() << "/"
    << data2.getMes() << "/" << data2.getAno() << ", e tem previs�o para sair �s " << horario2.getHora() <<
    ":" << horario2.getMinuto() << ":" << horario2.getSegundos() << ". \nEste v�o ainda possui " << voo2.vagas()
    << " assento(s) livres para serem ocupados" << endl;

    cout << "Em rela��o ao v�o " << voo2.getNumVoo() << " , iremos ocupar a cadeira de n�mero 40, para isso confirmaremos"
    " que ela est� vazia : ";
    if(voo2.verifica(40)){
        cout << "DISPON�VEL" << endl;
    }else{
        cout << "N�O DISPON�VEL" << endl;
    }

    return 0;
}
