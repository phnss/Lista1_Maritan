#ifndef VOO_H
#define VOO_H

#include "Horario.h"
#include "Data.h"

#include <string>

class Voo
{
    public:
        Voo();
        Voo(std::string ndv, Horario hdv, Data ddv);

        int proximoLivre();
        bool verifica(int cadeira);
        bool ocupa(int cadeira);
        int vagas();

        std::string getNumVoo();
        Data getData();
        Horario getHorario();

    private:
        Horario horarioDoVoo;
        Data dataDoVoo;

        int assentos[100] = {};
        std::string numeroDoVoo;


};

#endif // VOO_H
